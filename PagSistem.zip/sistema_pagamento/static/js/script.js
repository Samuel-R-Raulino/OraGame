function mostrarMensagem() {
    alert("Você clicou no botão!");
}
